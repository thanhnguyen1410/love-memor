# Love Memory

Website tình yêu/cặp đôi bằng Node.js + Express + SQLite.

## Tính năng

- Đăng ký, đăng nhập, đăng xuất.
- Tài khoản đầu tiên tự động là `admin`.
- Admin chỉnh tên website, logo, banner, background, màu chủ đạo, mục tiêu tiết kiệm.
- Profile cặp đôi: tên bạn, tên người ấy, ảnh đại diện, ngày bắt đầu yêu, ngày cưới.
- Hiển thị số ngày đã yêu và đếm ngược ngày cưới.
- Đồng hồ ngày giờ theo thời gian thực.
- Album kỉ niệm: ảnh, mô tả, ngày, địa điểm, Google Maps.
- Nhật ký theo lịch: chọn ngày, viết và lưu nhật ký mỗi ngày.
- Điểm danh mỗi ngày.
- Khoản tiết kiệm chung: thêm/xóa giao dịch, tổng tiền, tiến độ mục tiêu.
- Ước mơ của em và của anh riêng biệt.
- Nhắn tin trong app.
- Giao diện hồng/tím, responsive cho điện thoại.

## Cách chạy

```bash
npm install
npm start
```

Mở trình duyệt tại:

```bash
http://localhost:3000
```

## Cách dùng nhanh

1. Đăng ký tài khoản đầu tiên để trở thành admin.
2. Vào mục Admin để chỉnh tên website, banner, logo, background.
3. Vào Trang chủ để cập nhật profile, ngày bắt đầu yêu, ngày cưới.
4. Dùng Album, Nhật ký, Tiết kiệm, Ước mơ và Nhắn tin để lưu kỉ niệm.

## Lưu ý bảo mật

- Khi đưa lên hosting thật, hãy đặt biến môi trường `SESSION_SECRET` mạnh.
- Không commit file `love-memory.db`, `sessions.sqlite`, thư mục `node_modules` hoặc ảnh riêng tư.
- Nếu dùng cho nhiều cặp đôi, cần bổ sung mô hình phòng/couple riêng để tách dữ liệu từng cặp.

## Deploy gợi ý

Có thể chạy trên Replit, Render, Railway, VPS hoặc các nền tảng hỗ trợ Node.js.
