const app = document.querySelector('#app');
let state = { user: null, settings: {}, tab: 'dashboard', data: {} };
const $ = (id) => document.getElementById(id);

const api = async (url, options = {}) => {
  const res = await fetch(url, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Có lỗi xảy ra');
  return data;
};

const money = (n) => new Intl.NumberFormat('vi-VN').format(Number(n || 0)) + 'đ';
const today = () => new Date().toISOString().slice(0, 10);
const daysBetween = (from, to = new Date()) => {
  if (!from) return 0;
  const a = new Date(from + 'T00:00:00');
  const b = new Date(to.toISOString().slice(0, 10) + 'T00:00:00');
  return Math.max(0, Math.floor((b - a) / 86400000) + 1);
};
const countdown = (date) => {
  if (!date) return 'Chưa đặt ngày cưới';
  const diff = Math.ceil((new Date(date + 'T00:00:00') - new Date()) / 86400000);
  if (diff > 0) return `Còn ${diff} ngày`;
  if (diff === 0) return 'Chính là hôm nay 💍';
  return `Đã qua ${Math.abs(diff)} ngày`;
};
function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

async function boot() {
  const me = await api('/api/me');
  state.user = me.user;
  state.settings = me.settings;
  applyTheme();
  render();
  if (state.user) loadAll();
}

function applyTheme() {
  const s = state.settings || {};
  document.title = s.siteName || 'Love Memory';
  if (s.themeColor) document.documentElement.style.setProperty('--pink', s.themeColor);
  if (s.backgroundUrl) document.body.style.backgroundImage = `linear-gradient(135deg, rgba(255,243,248,.72), rgba(247,237,255,.74)), url('${s.backgroundUrl}')`;
}

function render() {
  if (!state.user) return renderAuth();
  app.innerHTML = `
    <div class="layout">
      <header class="topbar">
        <div class="brand">
          ${state.settings.logoUrl ? `<img class="logo" src="${state.settings.logoUrl}" alt="logo">` : `<div class="logo">💞</div>`}
          <div><div>${state.settings.siteName || 'Love Memory'}</div><div class="small">Xin chào ${state.user.name} ${state.user.role === 'admin' ? '• Admin' : ''}</div></div>
        </div>
        <nav class="nav">
          ${navButton('dashboard','Trang chủ')}
          ${navButton('memories','Album')}
          ${navButton('diary','Nhật ký')}
          ${navButton('dreams','Ước mơ')}
          ${navButton('saving','Tiết kiệm')}
          ${navButton('chat','Nhắn tin')}
          ${state.user.role === 'admin' ? navButton('admin','Admin') : ''}
          <button onclick="logout()">Đăng xuất</button>
        </nav>
      </header>
      <section class="hero" style="${state.settings.bannerUrl ? `background-image:linear-gradient(135deg, rgba(255,95,162,.70), rgba(124,58,237,.70)), url('${state.settings.bannerUrl}')` : ''}">
        <div><h1>${state.user.name} ${state.user.partner_name ? '❤ ' + state.user.partner_name : '❤ Love'}</h1><p>Mỗi ngày yêu nhau là một trang ký ức mới. Cùng lưu album, nhật ký, ước mơ, tiết kiệm và ngày cưới tại đây.</p></div>
      </section>
      <section id="screen"></section>
    </div>`;
  renderTab();
}

function navButton(tab, text) { return `<button class="${state.tab === tab ? 'active' : ''}" onclick="setTab('${tab}')">${text}</button>`; }
function setTab(tab) { state.tab = tab; render(); loadAll(); }

function renderAuth() {
  app.innerHTML = `
  <div class="auth">
    <div class="auth-card">
      <h1>💗 Love Memory</h1>
      <p class="small">Tạo không gian riêng cho hai người. Tài khoản đầu tiên đăng ký sẽ là admin.</p>
      <div class="form" id="authForm">
        <input class="input" id="name" placeholder="Tên của bạn" />
        <input class="input" id="email" placeholder="Email" />
        <input class="input" id="password" type="password" placeholder="Mật khẩu" />
        <button class="btn primary" onclick="register()">Đăng ký</button>
        <button class="btn" onclick="login()">Đăng nhập</button>
      </div>
    </div>
  </div>`;
}

async function register() {
  try {
    const data = await api('/api/register', { method:'POST', body: JSON.stringify({ name: $('name').value, email: $('email').value, password: $('password').value }) });
    state.user = data.user; toast(data.message || 'Đăng ký thành công'); render(); loadAll();
  } catch (e) { toast(e.message); }
}
async function login() {
  try {
    const data = await api('/api/login', { method:'POST', body: JSON.stringify({ email: $('email').value, password: $('password').value }) });
    state.user = data.user; toast('Đăng nhập thành công'); render(); loadAll();
  } catch (e) { toast(e.message); }
}
async function logout() { await api('/api/logout', { method:'POST' }); state.user = null; renderAuth(); }

async function loadAll() {
  if (!state.user) return;
  const load = async (key, url) => { try { state.data[key] = await api(url); } catch {} };
  await Promise.all([
    load('memories','/api/memories'), load('diaries','/api/diaries'), load('checkins','/api/checkins'),
    load('savings','/api/savings'), load('dreams','/api/dreams'), load('messages','/api/messages')
  ]);
  renderTab();
}

function renderTab() {
  const screen = $('screen');
  if (!screen) return;
  const mapMemory = (state.data.memories || []).find(m => m.map_url);
  const savings = state.data.savings || { rows: [], total: 0, goal: Number(state.settings.savingGoal || 0) };
  const progress = Math.min(100, Math.round((savings.total / Math.max(1, savings.goal || 1)) * 100));

  if (state.tab === 'dashboard') screen.innerHTML = `
    <div class="grid">
      <div class="card"><h3>Ngày đã yêu</h3><div class="stat">${daysBetween(state.user.love_start_date)}</div><p class="small">Tính từ ${state.user.love_start_date || 'chưa cập nhật'}</p></div>
      <div class="card"><h3>Đếm ngược ngày cưới</h3><div class="stat">💍</div><p>${countdown(state.user.wedding_date)}</p></div>
      <div class="card"><h3>Thời gian thực</h3><div id="clock" class="stat">--:--</div><p class="small" id="dateNow"></p></div>
      <div class="card wide"><h2>Profile cặp đôi</h2>${profileForm()}</div>
      <div class="card"><h2>Điểm danh hôm nay</h2><p class="small">Đã điểm danh ${state.data.checkins?.length || 0} ngày gần đây.</p><div class="form"><input class="input" id="checkMood" placeholder="Tâm trạng hôm nay" value="Nhớ người ấy"><textarea id="checkNote" placeholder="Lời nhắn điểm danh"></textarea><button class="btn primary" onclick="checkin()">Điểm danh 💗</button></div></div>
      <div class="card"><h2>Tiết kiệm chung</h2><div class="stat">${money(savings.total)}</div><div class="progress"><span style="width:${progress}%"></span></div><p class="small">Mục tiêu: ${money(savings.goal)} • ${progress}%</p></div>
      <div class="card full mapbox"><h2>Bản đồ vị trí kỉ niệm</h2>${mapMemory ? iframeFromMap(mapMemory.map_url) : '<p class="small">Thêm kỉ niệm có link Google Maps để hiện bản đồ tại đây.</p>'}</div>
    </div>`;

  if (state.tab === 'memories') screen.innerHTML = `
    <div class="grid"><div class="card wide"><h2>Thêm kỉ niệm</h2>${memoryForm()}</div><div class="card"><h2>Upload ảnh</h2>${uploadBox('memoryImageUrl')}</div><div class="card full"><h2>Album kỉ niệm</h2><div class="memory-grid">${(state.data.memories || []).map(memoryCard).join('') || '<p class="small">Chưa có kỉ niệm nào.</p>'}</div></div></div>`;

  if (state.tab === 'diary') screen.innerHTML = diaryScreen();
  if (state.tab === 'dreams') screen.innerHTML = dreamsScreen();
  if (state.tab === 'saving') screen.innerHTML = savingScreen();
  if (state.tab === 'chat') screen.innerHTML = chatScreen();
  if (state.tab === 'admin') screen.innerHTML = adminScreen();
  startClock();
}

function profileForm() { return `
  <div class="form">
    <div class="row"><input class="input" id="pfName" value="${state.user.name || ''}" placeholder="Tên bạn"><input class="input" id="pfPartner" value="${state.user.partner_name || ''}" placeholder="Tên người ấy"></div>
    <div class="row"><input class="input" id="pfLove" type="date" value="${state.user.love_start_date || ''}"><input class="input" id="pfWedding" type="date" value="${state.user.wedding_date || ''}"></div>
    <input class="input" id="pfAvatar" value="${state.user.avatar_url || ''}" placeholder="Link ảnh đại diện">
    <button class="btn primary" onclick="saveProfile()">Lưu profile</button>
  </div>`; }
async function saveProfile() {
  try {
    const data = await api('/api/profile', { method:'PATCH', body: JSON.stringify({ name:$('pfName').value, partner_name:$('pfPartner').value, love_start_date:$('pfLove').value, wedding_date:$('pfWedding').value, avatar_url:$('pfAvatar').value }) });
    state.user = data.user; toast('Đã lưu profile'); render();
  } catch(e) { toast(e.message); }
}
async function checkin() { try { await api('/api/checkins', { method:'POST', body: JSON.stringify({ mood:$('checkMood').value, note:$('checkNote').value }) }); toast('Đã điểm danh tình yêu'); loadAll(); } catch(e) { toast(e.message); } }

function uploadBox(targetId) { return `<div class="form"><input class="input" type="file" id="uploadFile" accept="image/*"><button class="btn primary" onclick="uploadImage('${targetId}')">Upload ảnh</button><input class="input" id="${targetId}" placeholder="Link ảnh sẽ hiện ở đây"></div>`; }
async function uploadImage(targetId) {
  const f = $('uploadFile').files[0]; if (!f) return toast('Chọn ảnh trước');
  const fd = new FormData(); fd.append('image', f);
  const res = await fetch('/api/upload', { method:'POST', body: fd }); const data = await res.json();
  if (!res.ok) return toast(data.error || 'Upload lỗi'); $(targetId).value = data.url; toast('Upload thành công');
}
function memoryForm() { return `<div class="form"><input class="input" id="mTitle" placeholder="Tiêu đề kỉ niệm"><textarea id="mDesc" placeholder="Mô tả"></textarea><div class="row"><input class="input" id="mDate" type="date"><input class="input" id="mLocation" placeholder="Tên địa điểm"></div><input class="input" id="mMap" placeholder="Link Google Maps hoặc link embed"><input class="input" id="memoryImageUrl" placeholder="Link ảnh hoặc upload bên cạnh"><button class="btn primary" onclick="addMemory()">Đăng kỉ niệm</button></div>`; }
async function addMemory() { try { await api('/api/memories', { method:'POST', body: JSON.stringify({ title:$('mTitle').value, description:$('mDesc').value, memory_date:$('mDate').value, location_name:$('mLocation').value, map_url:$('mMap').value, image_url:$('memoryImageUrl').value }) }); toast('Đã thêm kỉ niệm'); loadAll(); } catch(e) { toast(e.message); } }
function memoryCard(m) { return `<div class="item memory">${m.image_url ? `<img src="${m.image_url}" alt="${m.title}">` : ''}<h3>${m.title}</h3><p class="small">${m.memory_date || ''} ${m.location_name ? '• ' + m.location_name : ''}</p><p>${m.description || ''}</p><button class="btn danger" onclick="delMemory(${m.id})">Xóa</button></div>`; }
async function delMemory(id) { await api('/api/memories/'+id, { method:'DELETE' }); toast('Đã xóa'); loadAll(); }
function iframeFromMap(url) {
  if (!url) return '';
  const safe = url.includes('/embed') ? url : `https://www.google.com/maps?q=${encodeURIComponent(url)}&output=embed`;
  return `<iframe loading="lazy" src="${safe}"></iframe>`;
}

function diaryScreen() {
  const date = today();
  const entries = state.data.diaries || [];
  const days = calendarDays(entries);
  return `<div class="grid"><div class="card"><h2>Lịch nhật ký</h2><div class="calendar">${days}</div></div><div class="card wide"><h2>Viết nhật ký</h2><div class="form"><input class="input" type="date" id="dDate" value="${date}" onchange="fillDiary()"><input class="input" id="dTitle" placeholder="Tiêu đề hôm nay"><select id="dMood"><option>Yêu đời</option><option>Nhớ anh</option><option>Nhớ em</option><option>Hạnh phúc</option><option>Giận nhẹ</option></select><textarea id="dContent" placeholder="Viết điều muốn lưu lại hôm nay..."></textarea><button class="btn primary" onclick="saveDiary()">Đăng / lưu nhật ký</button></div></div><div class="card full"><h2>Nhật ký đã đăng</h2><div class="list">${entries.map(e => `<div class="item"><b>${e.diary_date} • ${e.title}</b><p class="small">${e.mood}</p><p>${e.content}</p></div>`).join('') || '<p class="small">Chưa có nhật ký.</p>'}</div></div></div>`;
}
function calendarDays(entries) {
  const set = new Set(entries.map(e => e.diary_date));
  const now = new Date(); const y = now.getFullYear(); const m = now.getMonth(); const total = new Date(y, m+1, 0).getDate();
  return Array.from({length: total}, (_,i) => { const d = `${y}-${String(m+1).padStart(2,'0')}-${String(i+1).padStart(2,'0')}`; return `<button class="day ${set.has(d)?'has':''} ${d===today()?'today':''}" onclick="selectDiaryDate('${d}')">${i+1}</button>`; }).join('');
}
function selectDiaryDate(d) { $('dDate').value = d; fillDiary(); }
function fillDiary() { const e = (state.data.diaries || []).find(x => x.diary_date === $('dDate').value); $('dTitle').value = e?.title || ''; $('dContent').value = e?.content || ''; $('dMood').value = e?.mood || 'Yêu đời'; }
async function saveDiary() { try { await api('/api/diaries', { method:'POST', body: JSON.stringify({ diary_date:$('dDate').value, title:$('dTitle').value, mood:$('dMood').value, content:$('dContent').value }) }); toast('Đã lưu nhật ký'); loadAll(); } catch(e) { toast(e.message); } }

function dreamsScreen() { const dreams = state.data.dreams || []; return `<div class="grid"><div class="card"><h2>Thêm ước mơ</h2><div class="form"><select id="dreamOwner"><option value="em">Ước mơ của em</option><option value="anh">Ước mơ của anh</option></select><textarea id="dreamText" placeholder="Ví dụ: cùng đi Đà Lạt, mua nhà, chụp ảnh cưới..."></textarea><button class="btn primary" onclick="addDream()">Thêm ước mơ</button></div></div><div class="card wide"><h2>Ước mơ của em & anh</h2><div class="row"><div><h3>Của em</h3><div class="list">${dreams.filter(d=>d.owner==='em').map(dreamItem).join('') || '<p class="small">Chưa có.</p>'}</div></div><div><h3>Của anh</h3><div class="list">${dreams.filter(d=>d.owner==='anh').map(dreamItem).join('') || '<p class="small">Chưa có.</p>'}</div></div></div></div></div>`; }
function dreamItem(d) { return `<div class="item"><b style="text-decoration:${d.done?'line-through':'none'}">${d.text}</b><div class="actions"><button class="btn" onclick="toggleDream(${d.id})">${d.done?'Bỏ hoàn thành':'Hoàn thành'}</button><button class="btn danger" onclick="delDream(${d.id})">Xóa</button></div></div>`; }
async function addDream() { try { await api('/api/dreams', { method:'POST', body: JSON.stringify({ owner:$('dreamOwner').value, text:$('dreamText').value }) }); toast('Đã thêm ước mơ'); loadAll(); } catch(e) { toast(e.message); } }
async function toggleDream(id) { await api('/api/dreams/'+id, { method:'PATCH' }); loadAll(); }
async function delDream(id) { await api('/api/dreams/'+id, { method:'DELETE' }); loadAll(); }

function savingScreen() { const s = state.data.savings || { rows:[], total:0, goal:0 }; const progress = Math.min(100, Math.round((s.total / Math.max(1, s.goal || 1))*100)); return `<div class="grid"><div class="card"><h2>Thêm khoản tiết kiệm</h2><div class="form"><select id="svPerson"><option>Chung</option><option>Anh</option><option>Em</option></select><input class="input" id="svAmount" type="number" placeholder="Số tiền"><input class="input" id="svNote" placeholder="Ghi chú"><button class="btn primary" onclick="addSaving()">Cập nhật tiết kiệm</button></div></div><div class="card"><h2>Tổng tiết kiệm</h2><div class="stat">${money(s.total)}</div><div class="progress"><span style="width:${progress}%"></span></div><p class="small">Mục tiêu ${money(s.goal)} • ${progress}%</p></div><div class="card wide"><h2>Lịch sử</h2><div class="list">${s.rows.map(r=>`<div class="item"><b>${r.person}: ${money(r.amount)}</b><p class="small">${r.created_at} • ${r.note || ''}</p><button class="btn danger" onclick="delSaving(${r.id})">Xóa</button></div>`).join('') || '<p class="small">Chưa có giao dịch.</p>'}</div></div></div>`; }
async function addSaving() { try { await api('/api/savings', { method:'POST', body: JSON.stringify({ person:$('svPerson').value, amount:$('svAmount').value, note:$('svNote').value }) }); toast('Đã cập nhật tiết kiệm'); loadAll(); } catch(e) { toast(e.message); } }
async function delSaving(id) { await api('/api/savings/'+id, { method:'DELETE' }); loadAll(); }

function chatScreen() { const msgs = state.data.messages || []; return `<div class="grid"><div class="card full"><h2>Nhắn tin cùng nhau</h2><div class="chat" id="chatBox">${msgs.map(m=>`<div class="msg ${m.sender===state.user.name?'me':''}"><b>${m.sender}</b><br>${m.body}<div class="small">${m.created_at}</div></div>`).join('') || '<p class="small">Chưa có tin nhắn.</p>'}</div><div class="form" style="margin-top:12px"><div class="row"><input class="input" id="msgSender" value="${state.user.name}"><input class="input" id="msgBody" placeholder="Nhập tin nhắn..."></div><button class="btn primary" onclick="sendMsg()">Gửi tin nhắn</button></div></div></div>`; }
async function sendMsg() { try { await api('/api/messages', { method:'POST', body: JSON.stringify({ sender:$('msgSender').value, body:$('msgBody').value }) }); $('msgBody').value=''; loadAll(); } catch(e) { toast(e.message); } }

function adminScreen() { const s = state.settings; return `<div class="grid"><div class="card wide"><h2>Quản trị giao diện</h2><div class="form"><input class="input" id="adName" value="${s.siteName || ''}" placeholder="Tên website"><input class="input" id="adLogo" value="${s.logoUrl || ''}" placeholder="Logo URL"><input class="input" id="adBanner" value="${s.bannerUrl || ''}" placeholder="Banner URL"><input class="input" id="adBg" value="${s.backgroundUrl || ''}" placeholder="Background URL"><div class="row"><input class="input" id="adColor" value="${s.themeColor || '#ff5fa2'}" placeholder="Màu chủ đạo"><input class="input" id="adGoal" type="number" value="${s.savingGoal || 10000000}" placeholder="Mục tiêu tiết kiệm"></div><button class="btn primary" onclick="saveAdmin()">Lưu cấu hình</button></div></div><div class="card"><h2>Gợi ý</h2><p class="small">Bạn có thể dùng link ảnh online hoặc upload ảnh trong mục Album rồi copy link ảnh sang đây.</p></div></div>`; }
async function saveAdmin() { try { const data = await api('/api/admin/settings', { method:'PATCH', body: JSON.stringify({ siteName:$('adName').value, logoUrl:$('adLogo').value, bannerUrl:$('adBanner').value, backgroundUrl:$('adBg').value, themeColor:$('adColor').value, savingGoal:$('adGoal').value }) }); state.settings = data.settings; applyTheme(); toast('Đã lưu admin'); render(); } catch(e) { toast(e.message); } }

let clockTimer;
function startClock() {
  clearInterval(clockTimer);
  const tick = () => {
    const now = new Date();
    if ($('clock')) $('clock').textContent = now.toLocaleTimeString('vi-VN', { hour:'2-digit', minute:'2-digit', second:'2-digit' });
    if ($('dateNow')) $('dateNow').textContent = now.toLocaleDateString('vi-VN', { weekday:'long', day:'2-digit', month:'2-digit', year:'numeric' });
  };
  tick(); clockTimer = setInterval(tick, 1000);
}

boot().catch(e => { app.innerHTML = `<div class="auth"><div class="auth-card"><h1>Lỗi</h1><p>${e.message}</p></div></div>`; });
