const express = require('express');
const session = require('express-session');
const SQLiteStore = require('connect-sqlite3')(session);
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'love-memory.db');
const UPLOAD_DIR = path.join(__dirname, 'uploads');

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      partner_name TEXT DEFAULT '',
      avatar_url TEXT DEFAULT '',
      love_start_date TEXT DEFAULT '',
      wedding_date TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS memories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT DEFAULT '',
      image_url TEXT DEFAULT '',
      memory_date TEXT DEFAULT '',
      location_name TEXT DEFAULT '',
      map_url TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS diaries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      diary_date TEXT NOT NULL,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      mood TEXT DEFAULT 'Yêu đời',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, diary_date),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS checkins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      checkin_date TEXT NOT NULL,
      mood TEXT DEFAULT 'Nhớ người ấy',
      note TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      UNIQUE(user_id, checkin_date),
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS savings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      person TEXT DEFAULT 'Chung',
      amount INTEGER NOT NULL,
      note TEXT DEFAULT '',
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS dreams (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      owner TEXT NOT NULL,
      text TEXT NOT NULL,
      done INTEGER DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      sender TEXT NOT NULL,
      body TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
  `);

  const defaults = {
    siteName: 'Love Memory',
    logoUrl: '',
    bannerUrl: '',
    backgroundUrl: '',
    themeColor: '#ff5fa2',
    savingGoal: '10000000'
  };
  const insert = db.prepare('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)');
  Object.entries(defaults).forEach(([k, v]) => insert.run(k, v));
}

initDb();

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  store: new SQLiteStore({ db: 'sessions.sqlite', dir: __dirname }),
  secret: process.env.SESSION_SECRET || 'love-memory-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 30, sameSite: 'lax' }
}));

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_');
    cb(null, Date.now() + '-' + safe);
  }
});
const upload = multer({ storage, limits: { fileSize: 5 * 1024 * 1024 } });

function currentUser(req) {
  if (!req.session.userId) return null;
  return db.prepare('SELECT id, name, email, role, partner_name, avatar_url, love_start_date, wedding_date, created_at FROM users WHERE id = ?').get(req.session.userId);
}

function requireAuth(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Vui lòng đăng nhập.' });
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  const user = currentUser(req);
  if (!user) return res.status(401).json({ error: 'Vui lòng đăng nhập.' });
  if (user.role !== 'admin') return res.status(403).json({ error: 'Chỉ admin mới được thao tác.' });
  req.user = user;
  next();
}

function settingsObject() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

function isValidDateString(value) {
  return !value || /^\d{4}-\d{2}-\d{2}$/.test(value);
}

app.get('/api/settings', (req, res) => res.json(settingsObject()));

app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error: 'Thiếu tên, email hoặc mật khẩu.' });
  if (password.length < 6) return res.status(400).json({ error: 'Mật khẩu tối thiểu 6 ký tự.' });

  const count = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  const role = count === 0 ? 'admin' : 'user';
  const hash = await bcrypt.hash(password, 10);
  try {
    const info = db.prepare('INSERT INTO users(name, email, password_hash, role) VALUES(?, ?, ?, ?)').run(name.trim(), email.trim().toLowerCase(), hash, role);
    req.session.userId = info.lastInsertRowid;
    res.json({ ok: true, user: currentUser(req), message: role === 'admin' ? 'Tài khoản đầu tiên là admin.' : 'Đăng ký thành công.' });
  } catch (e) {
    res.status(400).json({ error: 'Email đã tồn tại.' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(String(email || '').trim().toLowerCase());
  if (!user || !(await bcrypt.compare(password || '', user.password_hash))) {
    return res.status(401).json({ error: 'Email hoặc mật khẩu không đúng.' });
  }
  req.session.userId = user.id;
  res.json({ ok: true, user: currentUser(req) });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get('/api/me', (req, res) => res.json({ user: currentUser(req), settings: settingsObject() }));

app.patch('/api/profile', requireAuth, (req, res) => {
  const { name, partner_name, avatar_url, love_start_date, wedding_date } = req.body;
  if (!isValidDateString(love_start_date) || !isValidDateString(wedding_date)) return res.status(400).json({ error: 'Ngày phải đúng dạng YYYY-MM-DD.' });
  db.prepare(`UPDATE users SET name = ?, partner_name = ?, avatar_url = ?, love_start_date = ?, wedding_date = ? WHERE id = ?`)
    .run(name || req.user.name, partner_name || '', avatar_url || '', love_start_date || '', wedding_date || '', req.user.id);
  res.json({ ok: true, user: currentUser(req) });
});

app.post('/api/upload', requireAuth, upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Chưa chọn ảnh.' });
  res.json({ ok: true, url: `/uploads/${req.file.filename}` });
});

app.patch('/api/admin/settings', requireAdmin, (req, res) => {
  const allowed = ['siteName', 'logoUrl', 'bannerUrl', 'backgroundUrl', 'themeColor', 'savingGoal'];
  const update = db.prepare('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value');
  allowed.forEach(key => {
    if (Object.prototype.hasOwnProperty.call(req.body, key)) update.run(key, String(req.body[key] || ''));
  });
  res.json({ ok: true, settings: settingsObject() });
});

app.get('/api/memories', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM memories WHERE user_id = ? ORDER BY COALESCE(memory_date, created_at) DESC, id DESC').all(req.user.id);
  res.json(rows);
});

app.post('/api/memories', requireAuth, (req, res) => {
  const { title, description, image_url, memory_date, location_name, map_url } = req.body;
  if (!title) return res.status(400).json({ error: 'Thiếu tiêu đề kỉ niệm.' });
  db.prepare('INSERT INTO memories(user_id, title, description, image_url, memory_date, location_name, map_url) VALUES(?, ?, ?, ?, ?, ?, ?)')
    .run(req.user.id, title, description || '', image_url || '', memory_date || '', location_name || '', map_url || '');
  res.json({ ok: true });
});

app.delete('/api/memories/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM memories WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

app.get('/api/diaries', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM diaries WHERE user_id = ? ORDER BY diary_date DESC').all(req.user.id);
  res.json(rows);
});

app.get('/api/diaries/:date', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM diaries WHERE user_id = ? AND diary_date = ?').get(req.user.id, req.params.date);
  res.json(row || null);
});

app.post('/api/diaries', requireAuth, (req, res) => {
  const { diary_date, title, content, mood } = req.body;
  if (!diary_date || !title || !content) return res.status(400).json({ error: 'Thiếu ngày, tiêu đề hoặc nội dung nhật ký.' });
  db.prepare(`INSERT INTO diaries(user_id, diary_date, title, content, mood)
    VALUES(?, ?, ?, ?, ?)
    ON CONFLICT(user_id, diary_date) DO UPDATE SET title = excluded.title, content = excluded.content, mood = excluded.mood, updated_at = CURRENT_TIMESTAMP`)
    .run(req.user.id, diary_date, title, content, mood || 'Yêu đời');
  res.json({ ok: true });
});

app.get('/api/checkins', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM checkins WHERE user_id = ? ORDER BY checkin_date DESC LIMIT 60').all(req.user.id);
  res.json(rows);
});

app.post('/api/checkins', requireAuth, (req, res) => {
  const today = new Date().toISOString().slice(0, 10);
  const { mood, note } = req.body;
  db.prepare(`INSERT INTO checkins(user_id, checkin_date, mood, note)
    VALUES(?, ?, ?, ?)
    ON CONFLICT(user_id, checkin_date) DO UPDATE SET mood = excluded.mood, note = excluded.note`)
    .run(req.user.id, today, mood || 'Nhớ người ấy', note || 'Đã điểm danh tình yêu hôm nay 💗');
  res.json({ ok: true });
});

app.get('/api/savings', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM savings WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  const total = db.prepare('SELECT COALESCE(SUM(amount), 0) as total FROM savings WHERE user_id = ?').get(req.user.id).total;
  res.json({ rows, total, goal: Number(settingsObject().savingGoal || 0) });
});

app.post('/api/savings', requireAuth, (req, res) => {
  const { person, amount, note } = req.body;
  const money = Number(amount);
  if (!Number.isFinite(money) || money === 0) return res.status(400).json({ error: 'Số tiền không hợp lệ.' });
  db.prepare('INSERT INTO savings(user_id, person, amount, note) VALUES(?, ?, ?, ?)')
    .run(req.user.id, person || 'Chung', Math.round(money), note || '');
  res.json({ ok: true });
});

app.delete('/api/savings/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM savings WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

app.get('/api/dreams', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM dreams WHERE user_id = ? ORDER BY done ASC, created_at DESC').all(req.user.id);
  res.json(rows);
});

app.post('/api/dreams', requireAuth, (req, res) => {
  const { owner, text } = req.body;
  if (!['anh', 'em'].includes(owner) || !text) return res.status(400).json({ error: 'Thiếu người sở hữu hoặc nội dung ước mơ.' });
  db.prepare('INSERT INTO dreams(user_id, owner, text) VALUES(?, ?, ?)').run(req.user.id, owner, text);
  res.json({ ok: true });
});

app.patch('/api/dreams/:id', requireAuth, (req, res) => {
  db.prepare('UPDATE dreams SET done = CASE done WHEN 1 THEN 0 ELSE 1 END WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

app.delete('/api/dreams/:id', requireAuth, (req, res) => {
  db.prepare('DELETE FROM dreams WHERE id = ? AND user_id = ?').run(req.params.id, req.user.id);
  res.json({ ok: true });
});

app.get('/api/messages', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM messages WHERE user_id = ? ORDER BY id DESC LIMIT 80').all(req.user.id).reverse();
  res.json(rows);
});

app.post('/api/messages', requireAuth, (req, res) => {
  const { sender, body } = req.body;
  if (!body) return res.status(400).json({ error: 'Tin nhắn trống.' });
  db.prepare('INSERT INTO messages(user_id, sender, body) VALUES(?, ?, ?)').run(req.user.id, sender || req.user.name, body);
  res.json({ ok: true });
});

app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.listen(PORT, () => {
  console.log(`Love Memory đang chạy tại http://localhost:${PORT}`);
});
